import shutil
import firebase_admin
from firebase_admin import credentials, db
from azure.cosmos import CosmosClient, exceptions, PartitionKey
import boto3

def reset_firebase(firebase_url, firebase_credentials_path):
    """
    Clears all data from the specified Firebase Realtime Database.
    """
    try:
        # Initialize Firebase app
        cred = credentials.Certificate(firebase_credentials_path)
        if not firebase_admin._apps:
            firebase_admin.initialize_app(cred, {'databaseURL': firebase_url})

        # Reference the root of the database
        ref = db.reference('/')
        ref.delete()  # Deletes everything in the database

        print("Firebase database has been reset.")
    except Exception as e:
        print(f"Error resetting Firebase: {e}")

def reset_s3(bucket_names, aws_access_key, aws_secret_key, aws_region):
    """
    Deletes all objects from the specified AWS S3 bucket.
    """
    try:
        # Initialize S3 client
        s3_client = boto3.client(
            's3',
            aws_access_key_id=aws_access_key,
            aws_secret_access_key=aws_secret_key,
            region_name=aws_region
        )

        for bucket_name in bucket_names:
            # List all objects in the bucket
            response = s3_client.list_objects_v2(Bucket=bucket_name)
            if 'Contents' in response:
                for obj in response['Contents']:
                    s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
                    print(f"Deleted {obj['Key']} from S3.")

            print("S3 bucket has been reset.")
    except Exception as e:
        print(f"Error resetting S3: {e}")
        
def reset_cosmos(cosmos_endpoint, cosmos_key, database_names):
    """
    Deletes all containers and their data within the specified Cosmos DB databases.
    """
    try:
        # Initialize Cosmos DB client
        cosmos_client = CosmosClient(cosmos_endpoint, cosmos_key)
        
        for database_name in database_names:
            try:
                # Get the database
                database = cosmos_client.get_database_client(database_name)
                
                # List all containers and delete them
                containers = list(database.list_containers())
                for container in containers:
                    container_name = container['id']
                    database.delete_container(container_name)
                    print(f"Deleted container '{container_name}' in database '{database_name}'.")

                # Delete the database itself
                cosmos_client.delete_database(database_name)
                print(f"Deleted database '{database_name}'.")
            
            except exceptions.CosmosResourceNotFoundError:
                print(f"Database '{database_name}' not found. Skipping.")
    
    except Exception as e:
        print(f"Error resetting Cosmos DB: {e}")

if __name__ == "__main__":
    # Firebase Configuration
    FIREBASE_URL = 'https://projetopsd-5a681-default-rtdb.europe-west1.firebasedatabase.app/'  # Replace with your Firebase URL
    FIREBASE_CREDENTIALS_PATH = "projetopsd-5a681-19d45fdfc118.json"  # Path to Firebase service account JSON file

    # AWS S3 Configuration
    S3_BUCKET_NAMES = ["projetopsd1","projetopsd2","projetopsd3","projetopsd4"]  # Replace with your S3 bucket name
    AWS_ACCESS_KEY = 'AKIAQR5EPGH6RTK32M56'  # Replace with your AWS access key
    AWS_SECRET_KEY = 'z4TCt1JyLPFeYoLEO/j7ei+550sMmuUdusoxPnSw'  # Replace with your AWS secret key
    AWS_REGION = 'us-east-1'  # Replace with your AWS region (e.g., "us-east-1")
    
    COSMOS_ENDPOINT = "https://projetopsd.documents.azure.com:443/"
    COSMOS_KEY = "8623mjb8FhTWVRLmgqeXaq5vLs5qZHuGXX4vSzm3WcXdf9DuHskbEbPpEgxoSY14HlRRMLffbvBeACDbiBWFMQ=="

    # Perform reset operations
    reset_firebase(FIREBASE_URL, FIREBASE_CREDENTIALS_PATH)
    reset_s3(S3_BUCKET_NAMES, AWS_ACCESS_KEY, AWS_SECRET_KEY, AWS_REGION)
    reset_cosmos(COSMOS_ENDPOINT, COSMOS_KEY, S3_BUCKET_NAMES)
    shutil.rmtree("peersList")