PSD

André Belo fc58211

Diogo Serrano Sargaço fc58252

Rodrigo Rodrigues fc64370

Para executar o ficheiro deve-se inserir na terminal o seguinte comando: "python3 .\p2pchat_phase2.py". Os certificados são criados para cada port quando a aplicação for executada.

Para dar reset à base de dados tem-se o ficheiro reset_databases.py